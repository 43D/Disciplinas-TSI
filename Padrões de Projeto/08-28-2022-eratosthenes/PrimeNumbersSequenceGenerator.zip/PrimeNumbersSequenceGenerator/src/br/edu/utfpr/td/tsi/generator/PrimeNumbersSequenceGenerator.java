package br.edu.utfpr.td.tsi.generator;

import java.util.List;

public interface PrimeNumbersSequenceGenerator {
	public List<Integer> primeSequenceTo(int max);
}
