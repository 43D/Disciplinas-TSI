package br.edu.utfpr.td.tsi.generators;

import java.util.List;

public interface ISequenceGenerator {
	public List<Integer> generateSequence(final int MAX);
}
