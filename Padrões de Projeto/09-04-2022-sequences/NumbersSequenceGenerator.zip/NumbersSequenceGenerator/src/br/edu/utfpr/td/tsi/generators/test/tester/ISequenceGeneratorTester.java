package br.edu.utfpr.td.tsi.generators.test.tester;

public interface ISequenceGeneratorTester {

	public abstract void test();
	
}
