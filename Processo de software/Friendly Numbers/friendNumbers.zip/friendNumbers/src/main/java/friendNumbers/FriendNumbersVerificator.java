package friendNumbers;

public interface FriendNumbersVerificator 
{
	boolean areFriends(final long numberA, final long numberB);
}
