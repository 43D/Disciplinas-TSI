package morse.codec;

public interface MorseDecoder 
{
	String decode(String morseText);
}
