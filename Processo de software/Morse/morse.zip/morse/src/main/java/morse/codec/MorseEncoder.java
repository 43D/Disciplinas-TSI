package morse.codec;

public interface MorseEncoder 
{
	String encode(String text);
}
