package morse.codec.impl;

public interface MorseDecodeMap {
    public String decode(String morseCode) throws Exception;
}
