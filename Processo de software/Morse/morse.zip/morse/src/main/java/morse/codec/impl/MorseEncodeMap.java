package morse.codec.impl;

public interface MorseEncodeMap{
    public String encode(char letter) throws Exception;
}