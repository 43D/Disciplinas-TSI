package morse.codec;

import org.junit.jupiter.api.Test;

public class MorseCodecFactoryTest {
    @Test
    void testCreateDecoder() {

    }

    @Test
    void testCreateEncoder() {

    }
}
